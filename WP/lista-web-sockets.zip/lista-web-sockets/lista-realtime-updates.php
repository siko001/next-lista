<?php
/**
 * Plugin Name: Lista Realtime Updates
 * Description: Sends real-time update events via Pusher when lists are modified.
 */

require_once __DIR__ . '/vendor/autoload.php';
use Pusher\Pusher;


// Pusher Setup
function setup_pusher() {
    return new Pusher(
        'a9f747a06cd5ec1d8c62', 
        'c30a7a8803655f65cdaf',
        '1990193',              
        [
            'cluster' => 'eu',
            'useTLS'  => true
        ]
    );
}


function trigger_list_update($list_id, $data) {
    $pusher = setup_pusher();
    $channel = 'shopping-list-' . $list_id;
    $pusher->trigger($channel, 'list-updated', $data);
}


add_action('save_post_shopping-list', function($post_id, $post, $update) {
    // Only trigger on update, not on initial creation
    if ($update) {
        // Prepare your data array (e.g., fetch ACF fields)
        $data = [
            'list_id' => $post_id,
            // Add other relevant fields here
        ];
        trigger_list_update($post_id, $data);
    }
}, 10, 3);























// Example hook: trigger when a post is updated (replace with your custom logic)
// add_action('save_post', function($post_id, $post, $update) {

    
//     $pusher = new Pusher(
//         'a9f747a06cd5ec1d8c62',
//         'c30a7a8803655f65cdaf',
//         '1990193',
//         [
//             'cluster' => 'eu',
//             'useTLS' => true
//         ]
//     );

//     $data = [
//         'list_id' => $post_id,
//         'title' => $post->post_title,
//         'owner_id' => get_field("owner_id", $post_id),
//         "shared_with_users" => get_field('shared_with_users',$post_id)
//     ];

//     $pusher->trigger('lista-channel', 'list-updated', $data);
// }, 10, 3);





// add_action('acf/save_post', function($post_id) {
    // Only trigger for your list post type
    // if (get_post_type($post_id) !== 'list') return;

    // Get field values
    // $data = [
    //     'list_id' => $post_id,
    //     'title' => get_the_title($post_id),
    //     'owner_id' => get_field('owner_id', $post_id),
    //     'shared_with_users' => get_field('shared_with_users', $post_id)
    // ];

    //     // Initialize Pusher (FIXED: added 'new' keyword)
    //     $pusher = new Pusher(
    //         'a9f747a06cd5ec1d8c62',
    //         'c30a7a8803655f65cdaf',
    //         '1990193',
    //         [
    //             'cluster' => 'eu',
    //             'useTLS' => true
    //         ]
    //     );
        
    //     // Broadcast to public channel (temporary)
    //     $pusher->trigger('lista-channel', 'list-updated', $data);
// }, 20);


// add_action('acf/save_post', function($post_id) {
//     $post = get_post($post_id);
//     if (!$post) return;

//     // Get fields you want to send
//     $title = get_the_title($post_id);
//     $owner_id = get_field( 'owner_id', $post_id); 
//     $shared_with_users = get_field('shared_with_users', $post_id);

//     // Send to Pusher
//     $pusher = Pusher(
//         'a9f747a06cd5ec1d8c62',
//         'c30a7a8803655f65cdaf',
//         '1990193',
//         [
//             'cluster' => 'eu',
//             'useTLS' => true
//         ]
//     );

//     $pusher->trigger('lista-channel', 'list-updated', [
//         'list_id' => $post_id,
//         'title' => $title,
//         'owner_id' => $owner_id,
//         'shared_with_users' => $shared_with_users
//     ]);
// }, 20);
